from __future__ import print_function
#import json
import base64
def lambda_handler(event, context):
    try:
        for record in event['Records']:
            payload = base64.b64encode(record["kinesis"]["data"])
            response = str(payload)
        return {
            'status': 'Done',
            'body': json.dumps(response)
        }
    except Exception as e:
        raise(e)
